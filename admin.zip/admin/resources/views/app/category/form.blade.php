<div class="form-group">
    {!! Form::label('name', 'Category Name', ['class' => 'col-sm-2 control-label']) !!}
    <div class="col-sm-10">
        {!! Form::text('name', NULL, ['class' => 'form-control', "placeholder" => "Category Name"]) !!}
    </div>
</div>