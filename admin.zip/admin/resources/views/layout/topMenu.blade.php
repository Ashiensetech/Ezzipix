<header class="main-header">
    <a href="{{ url("dashboard") }}" class="logo">
        <span class="logo-mini"><b>E</b>A</span>
        <span class="logo-lg"><b>Ezeepix</b>Admin</span>
    </a>
    <nav class="navbar navbar-static-top" role="navigation">
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
    </nav>
    @yield("menuItems")
</header>